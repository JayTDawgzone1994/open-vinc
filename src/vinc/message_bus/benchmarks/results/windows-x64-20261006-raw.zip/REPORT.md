# Message Bus benchmark

Latency: send call entry to subscriber callback entry.
Warmup excluded from percentiles. No-collision runs are paced, not saturation throughput.

| Mode | MiB | Slots | Hz (actual) | P50 ms | P90 ms | P99 ms | Max ms | MiB/s | Clean |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| push | 1 | 8 | 63.64 | 15.185 | 16.292 | 16.415 | 16.863 | 63.64 | True |
| loan | 1 | 8 | 63.59 | 15.875 | 15.988 | 16.077 | 16.458 | 63.59 | True |
| push | 2 | 8 | 63.77 | 1.698 | 16.535 | 16.643 | 16.794 | 127.67 | True |
| loan | 2 | 8 | 63.64 | 15.781 | 15.960 | 16.134 | 16.477 | 127.29 | True |
| push | 4 | 8 | 63.72 | 3.222 | 17.034 | 17.244 | 18.311 | 255.10 | True |
| loan | 4 | 8 | 63.73 | 15.681 | 15.881 | 16.104 | 16.359 | 254.92 | True |
| push | 8 | 8 | 63.66 | 4.719 | 17.866 | 18.132 | 18.479 | 509.65 | True |
| loan | 8 | 8 | 63.69 | 15.347 | 15.758 | 16.157 | 16.764 | 509.55 | True |
| push | 16 | 8 | 63.63 | 8.719 | 19.702 | 20.152 | 20.358 | 1018.66 | True |
| loan | 16 | 8 | 63.92 | 14.718 | 15.862 | 17.185 | 29.992 | 1022.85 | True |
| push | 32 | 8 | 63.65 | 18.909 | 23.022 | 23.792 | 25.081 | 2036.00 | True |
| loan | 32 | 8 | 32.16 | 13.134 | 14.025 | 14.621 | 15.876 | 1029.68 | True |
| push | 64 | 63 | 31.88 | 26.753 | 27.827 | 30.883 | 47.464 | 2040.46 | True |
| loan | 64 | 8 | 30.05 | 12.140 | 28.382 | 32.548 | 33.933 | 1924.40 | True |
| push | 128 | 31 | 15.92 | 37.004 | 38.366 | 40.596 | 56.388 | 2038.65 | True |
| loan | 128 | 8 | 15.96 | 34.915 | 36.539 | 39.380 | 71.691 | 2044.22 | True |

Full prepare/send distributions, resource metrics, loss and collision counters: summary.csv.
Raw timestamps and unsuccessful calibration attempts are retained in individual directories.
CPU includes warmup/setup/drain in each process's own window. 100% = one logical core.
Peak RSS includes shared pages and must not be summed as physical RAM.
Loan preparation includes get_next + resize/zero-fill; push reuses a prepared local message.
128 samples in pilots are calibration only; 1,000 final samples give about 10 upper-tail observations.
